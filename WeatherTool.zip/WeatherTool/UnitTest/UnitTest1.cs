using NUnit.Framework;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using WeatherTool;
using WeatherTool.Models;

namespace UnitTest
{
    [TestFixture]
    public class Tests
    {
        string input;
        HttpClient client;
        [SetUp]
        public void Setup()
        {
            input = "Mumbai";
            client = new HttpClient();
            client.BaseAddress = new Uri("https://api.open-meteo.com/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        [Test]
        public void Test1()
        {
            var result = Weather.GetWeather(client, input);
            Assert.IsTrue(result.Result.City == input);
        }
    }
}