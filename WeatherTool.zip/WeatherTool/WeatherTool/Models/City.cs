﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTool.Models
{
    public class City
    {
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public double GenerationTime_MS { get; set; }
        public int UTC_Offset_seconds { get; set; }
        public string Timezone { get; set; }
        public string Timezone_Abbreviation { get; set; }
        public float Elevation { get; set; }
        public Current_Weather Current_Weather { get; set; }
    }
}
