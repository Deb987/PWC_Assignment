﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTool.Models
{
    public class CityDetails
    {
        public string City { get; set; }
        public decimal Lat { get; set; }
        public decimal Lng { get; set; }
        public string Country { get; set; }
        public string ISO2 { get; set; }
        public string Admin_Name { get; set; }
        public string Capital { get; set; }
        public long? Population { get; set; }
        public long? Population_Proper { get; set; }
    }
}
