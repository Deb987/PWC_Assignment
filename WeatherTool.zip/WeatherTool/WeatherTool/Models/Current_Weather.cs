﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTool.Models
{
    public class Current_Weather
    {
        public float Temperature { get; set; }
        public float WindSpeed { get; set; }
        public float WindDirection { get; set; }
        public int WeatherCode { get; set; }
        public DateTime Time { get; set; }
    }
}
