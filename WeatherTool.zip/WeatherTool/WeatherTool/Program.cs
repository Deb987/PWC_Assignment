﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using WeatherTool.Models;

namespace WeatherTool
{
    public class Weather
    {
        public static async Task<CityDetails> GetWeather(HttpClient cons, string inputVal)
        {

            using (StreamReader r = new StreamReader("file.json"))
            {
                string json = r.ReadToEnd();
                List<CityDetails> items = JsonConvert.DeserializeObject<List<CityDetails>>(json);

                string input = inputVal.Trim();
                var cityDetail = new CityDetails();
                int count = 0;
                foreach (var item in items)
                {
                    if (item.City.Trim().ToLower() == input.Trim().ToLower())
                    {
                        cityDetail = item;
                        count++;
                        break;
                    }
                }

                using (cons)
                {
                    if (count > 0)
                    {
                        HttpResponseMessage res = await cons.GetAsync($"v1/forecast?latitude={cityDetail.Lat}&longitude={cityDetail.Lng}&current_weather=true");

                        if (res.IsSuccessStatusCode)
                        {
                            City city = await res.Content.ReadAsAsync<City>();
                            Console.WriteLine("Weather Report for {0}: ", cityDetail.City);
                            Console.WriteLine("Temperature: " + city.Current_Weather.Temperature);
                            Console.WriteLine("Wind speed: " + city.Current_Weather.WindSpeed);
                            Console.WriteLine("Wind direction: " + city.Current_Weather.WindDirection);
                            Console.WriteLine("Weather code: " + city.Current_Weather.WeatherCode);
                            Console.WriteLine("Time: " + city.Current_Weather.Time);
                            
                            return cityDetail;
                        }
                        else
                        {
                            Console.WriteLine("Weather not found!");
                            return null;
                        }
                    }
                    else
                    {
                        Console.WriteLine("City not found!");
                        return null;
                    }
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://api.open-meteo.com/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            Console.WriteLine("Enter City: ");
            var input = Console.ReadLine();
            try
            {
                Weather.GetWeather(client, input).Wait();
                Console.WriteLine();
                Console.WriteLine("Press any key to exit.");
                Console.ReadLine();
            }
            catch(Exception e)
            {
                Console.WriteLine("Unable to connect to API! Make sure you are connected to the internet.");
            }
        }

        
    }
}
